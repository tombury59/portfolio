#|-------------------------------------------------------------------------|#
#|                        Importation des modules                          |#
#|-------------------------------------------------------------------------|#

import csv
from tkinter import *
from random import *
import time






#|-------------------------------------------------------------------------|#
#|                             Initialisation                              |#
#|-------------------------------------------------------------------------|#


fenetre = Tk()
fenetre.title('Jeux des PAIRES')


canvas = Canvas(fenetre, width=600, height=600, background='white')

# Cette partie affichera un Label avec les nombres d'essais du joueur
var = StringVar()
label = Label(fenetre, textvariable=var, relief=RAISED,width=50,bg='cyan',borderwidth=5,font=('modern',15))

var.set("Nombre d'essaie:")


# 
# with open('Classement', 'w') as f:
#     # create the csv writer
#     writer = csv.writer(f)
# 
#     # write a row to the csv file
#     writer.writerow([" Nom "," Temps "," Score "])
# 



#|-------------------------------------------------------------------------|#
#|                             Variable                                    |#
#|-------------------------------------------------------------------------|#


tab=[[ 0 , 0 , 0 , 0],
     [ 0 , 0 , 0 , 0],
     [ 0 , 0 , 0 , 0]]


# Compteur va calculer le nombre de coup du joueur ( nombre de clique // 2 )
compteur=0


# Autorisation autorisera ou non l'utilisateur a cliquer
# si le joueur demande la solution : autorisation passe en False et bloque le clique
autorisation=True


# Differentes variables qui seront utilisés lors de la fonction Clic()
coo=[]
coo_trouve=[]
carte_test=[]
res_trouve=[]



colonne=["Pseudo","Temps","Essais"]


# Start initie le Timer a 0 et s'arretera lorsque soit la solution est demandé ou la grille est compléte
start=time.time()



# Ici on importe tous les images du dossier

Roi1=PhotoImage(file='CarteR1.png')
Roi2=PhotoImage(file='CarteR2.png')

Dame1=PhotoImage(file='CarteD1.png')
Dame2=PhotoImage(file='CarteD2.png')

Valet1=PhotoImage(file='CarteV1.png')
Valet2=PhotoImage(file='CarteV2.png')


DosCarte=PhotoImage(file='VraiDosCartes2.png')

a=Roi1
b=Roi2

c=Dame1
d=Dame2

e=Valet1
f=Valet2





#|-------------------------------------------------------------------------|#
#|                             Fonction                                    |#
#|-------------------------------------------------------------------------|#



# Cette fonction modifie le canvas et crée la grille de cartes.
def create_canvas():
    
    global DosCartes
   
    canvas.create_line(0,0,0,600,width=20)
    canvas.create_line(0,0,600,0,width=20)
    
    canvas.create_line(600,0,600,600,width=10)
    canvas.create_line(600,600,0,600,width=10)
    
    
    for i in range(0,3):
        for j in range(0,4):
            
            canvas.create_image(75+j*150 ,100+i*200 , image=DosCarte)
            



# A chaque clique gauche du joueur , la crée a son emplacement ( millieu d'une case ) la valeur correspondante
# qui sera ajouté a "carte_test" , ainsi que ses coordonnées qui seront ajoutées a "coo".

# Au deuxiéme clique , on ajoute aussi la valeur et les coordonnées pour ensuite pour les comparer :
#             si les valeurs sont identiques ==> on laisse afficher les valeurs et on les sauvegarde
#                dans "res_trouve" et leurs coordonnées "dans coo_trouve"
#             sinon on supprime le tableau actuel , on reaffiche les valeurs deja trouvé ,
#                et on recommence jusqu'a finir la grille

# Enfin on test si la grille est remplie grace a "res_trouve" ( si res_trouve==12 ( nombre de cases ) )
# si c'est le cas : on affiche un message de victoire.
def Clic(event):
    
    global tab,carte_test,coo,res_trouve,var,label,compteur,end,autorisation
    
    if autorisation==True:

        compteur+=1
        var.set("Nombre d'essais: "+ str(compteur//2))

        X=event.x 
        Y=event.y
        
        X=X//150
        Y=Y//200
     
        
        text1=canvas.create_image(75+X*150 ,100+Y*200 , image=tab[Y][X])
        
        carte_test.append(tab[Y][X])
        coo.append((X,Y))
        

# A activer ou non pour faire des essais sur le fonctionnement du programme.
# Il affichera toutes valeurs attribués lors de chaque clic au variables globale.
      

        if len(carte_test)>2:
                
            
            if carte_test[0] != carte_test[1]:
                a=carte_test[2]
                carte_test=[]
                carte_test.append(a)
                
                
                b=coo[2]
                coo=[]
                coo.append(b)
                
                
                if len(coo)>2:
                    coo=[]
                
                canvas.create_rectangle(0,0,600,600,fill='white')            
                create_canvas()
                
       
                text1=canvas.create_image(75+X*150 ,100+Y*200 , image=tab[Y][X])
                
                
            
                
            else:
                
                if carte_test[0] not in res_trouve:
                    
                    res_trouve.append((carte_test[0]))
                    res_trouve.append((carte_test[1]))
                    
                if coo[0] or coo[1] not in coo_trouve:
                    
                    coo_trouve.append(coo[0])
                    coo_trouve.append(coo[1])
                
                b=coo[2]
                coo=[]
                coo.append(b)

                
                a=carte_test[2]
                carte_test=[]
                carte_test.append(a)
        
        

        if len(res_trouve)>0:

            
            for i in range(len(res_trouve)):
                canvas.create_image(  75+coo_trouve[i][0]*150 ,100+coo_trouve[i][1]*200  , image=res_trouve[i])



        if len(res_trouve)==12:
            end=time.time()
            messagebox.showinfo('FIN DE PARTIE', 'Bravo , tu as réussi en : ' + str(round(end-start)) + ' secondes' + ' et en ' + str(compteur//2) + ' essais')
            autorisation=False

# Cette fonction permet de modifier aleatoirement le tableau avec des valeurs données dans "nb"
# et renvoie un tableau aleatoire
def genere_tab_random():
    global tab,a,b,c,d,e,f

    nb=[a,a,b,b,c,c,d,d,e,e,f,f]

    for i in range(0,3):
        for j in range(0,4):
            a=randint(0,len(nb)-1)
    
            b=nb[a]
            

            nb.pop(a)
            
            tab[i][j]=b
    
    return tab
    





# Cette fonction affichera toutes les valeurs du tableau aleatoire et
# affichera une Fin de Partie
def solution():
    global tab,autorisation,a,b,c,d,e,f

    for i in range(0,3):
        for j in range(0,4):
            
            canvas.create_image(75+j*150 ,100+i*200 , image=tab[i][j])
            
    autorisation=False
    messagebox.showinfo('FIN DE LA PARTIE', 'Abandon :( ')
            
    return





#|-------------------------------------------------------------------------|#
#|                         Lancement du programme                          |#
#|-------------------------------------------------------------------------|#



# Creation du boutton pour afficher la solution du tableau 
Button(fenetre, text ='Solution' ,font=('Impact',10),bg='cyan',width=20,borderwidth=5,command=solution) .pack ( padx=5, pady=5)

# Asscociation du clique gauche a la fonction "Clic"
canvas.bind("<Button-1>",Clic)


# On modifie le tableau et on modifie canvas ( mise a blanc )
tab=genere_tab_random()
create_canvas()



label.pack()
canvas.pack()
fenetre.mainloop()